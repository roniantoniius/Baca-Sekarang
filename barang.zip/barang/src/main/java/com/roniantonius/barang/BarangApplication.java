package com.roniantonius.barang;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BarangApplication {

	public static void main(String[] args) {
		SpringApplication.run(BarangApplication.class, args);
	}

}
